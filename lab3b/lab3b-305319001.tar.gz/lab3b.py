#!/bin/python
import csv
import sys

def parse(file):
  min = 12
  max = 27
  single = 24
  double = 25
  triple = 26
  masterList = list()
  inodes = list()
  dirents = list()
  indirects = list()
  blockDict = dict()
  inodeDict = dict()
  familyTree = dict()
  counter = dict()

  #add the contents of the file into masterList so they can be easily analyzed
  for entry in file:
    masterList.append(entry)

  #iterate through masterList, set variables based on 'title'
  for entry in masterList:
    title = entry[0]
    temp = int(entry[1])
    if title == "DIRENT":
      dirents.append(entry)
    elif title == "INDIRECT":
      indirects.append(entry)
    elif title == "IFREE":
      inodeDict[temp] = 0
    elif title == "BFREE":
      blockDict[temp] = 0
    elif title == "GROUP":
      inodeNum = int(entry[3])
      inodeTable = int(entry[8])
      inodeNumPlus = inodeNum + 1
      blockNum = int(entry[2])
    elif title == "INODE":
      inodes.append(entry)
      selfNum = int(entry[1])
      if selfNum not in inodeDict:
        inodeDict[selfNum] = 1 
      else:
        inodeDict[selfNum] = -1
        print("ALLOCATED INODE " + entry[1] + " ON FREELIST")
    elif title == "SUPERBLOCK":
      inodeSize = int(entry[4])
      unreservedInode = int(entry[7])
      blockSize = int(entry[3])
  afterBlock = (int(inodeNum * inodeSize) // int(blockSize)) + int(inodeTable)


  #Block consistency audits
  for n in inodes:
    for j in range(min, max):
      current = int(n[j])
      number = n[1]
      if current == 0:
        continue
      #check if blocks are invalid or reserved
      if current not in blockDict:
        if inodeTable > current:
          if j == triple:
            print("RESERVED TRIPLE INDIRECT BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 65804")
          elif j == double:
            print("RESERVED DOUBLE INDIRECT BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 268")
          elif j == single:
            print("RESERVED INDIRECT BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 12")
          else:
            print("RESERVED BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 0")
        if current > blockNum or current < 0:
          if j == triple:
            print("INVALID TRIPLE INDIRECT BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 65804")
          elif j == double:
            print("INVALID DOUBLE INDIRECT BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 268")
          elif j == single:
            print("INVALID INDIRECT BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 12")
          else:
            print("INVALID BLOCK " + str(current) + " IN INODE " + number + " AT OFFSET 0")
        else:
          if j == single:
            blockDict[current] = (number, "INDIRECT BLOCK ", 12)
          elif j == double:
            blockDict[current] = (number, "DOUBLE INDIRECT BLOCK ", 268)
          elif j == triple:
            blockDict[current] = (number, "TRIPLE INDIRECT BLOCK ", 65804)
          else:
            blockDict[current] = (number, "BLOCK ", 0)
      #legal block gets referenced by multiple files (or even multiple times in a single file) 
      elif blockDict[current] != 0:
        first = blockDict[current][1]
        second = blockDict[current][0]
        third = str(blockDict[current][2])
        print("DUPLICATE " + first + str(current) + " IN INODE " + second + " AT OFFSET " + third)
        if j == single:
          blockDict[current] = (number, "INDIRECT BLOCK ", 12, 1) 
        elif j == double:
          blockDict[current] = (number, "DOUBLE INDIRECT BLOCK ", 268, 1) 
        elif j == triple:
          blockDict[current] = (number, "TRIPLE INDIRECT BLOCK ", 65804, 1) 
        else:
          blockDict[current] = (number, "BLOCK ", 0, 1)
      #block that is allocated to a file may also appear on the free list
      elif blockDict[current] == 0:
        print("ALLOCATED BLOCK " + str(current) + " ON FREELIST")
          

  #I-node Allocation Audits
  for j in range(unreservedInode, inodeNumPlus):
    if j not in inodeDict:
      number = str(j)
      print("UNALLOCATED INODE " + number + " NOT ON FREELIST")


  #check if entry refers to itself or its parent (first chunk of the for loop)
  #check the validity and allocation status of each referenced I-node (second chunk of for loop)
  #check the link count and check if inode was properly allocated (bottom chunk of for loop)
  for entry in dirents:
    parentNum = entry[1]
    selfNum = entry[3]
    intSelfNum = int(selfNum)
    name = entry[6]
    #parent
    if name == "'..'":
      if (parentNum != selfNum) and (parentNum not in familyTree):
        print("DIRECTORY INODE " + parentNum + " NAME '..' LINK TO INODE " + selfNum + " SHOULD BE " + parentNum)
      elif parentNum in familyTree:
        if selfNum != familyTree[parentNum]:
          print("DIRECTORY INODE " + parentNum + " NAME '..' LINK TO INODE " + selfNum + " SHOULD BE " + familyTree[parentNum])
    #child
    elif name == "'.'":
      if parentNum != selfNum:
        print("DIRECTORY INODE " + parentNum + " NAME '.' LINK TO INODE " + selfNum + " SHOULD BE " + parentNum)
    #neither, add it
    elif name != '..' and name != '.':
      familyTree[selfNum] = parentNum

    #unallocated inode
    if (intSelfNum in inodeDict) and (inodeDict[intSelfNum] == 0):
      print("DIRECTORY INODE " + parentNum + " NAME " + name + " UNALLOCATED INODE " + selfNum)
    #invalid inode
    elif (intSelfNum > inodeNum) or (intSelfNum < 1):
      print("DIRECTORY INODE " + parentNum + " NAME " + name + " INVALID INODE " + selfNum)
    
    if selfNum in counter:
      counter[selfNum] = counter[selfNum] + 1
    elif selfNum not in counter:
      counter[selfNum] = 1
    else:
      continue


  #every allocated I-node should be referred to by the number of directory entries that is equal to the reference count recorded in the I-node
  for entry in inodes:
    selfNum = entry[1]
    linkCount = int(entry[6])
    if selfNum not in counter:
      print("INODE " + selfNum + " HAS 0 LINKS BUT LINKCOUNT IS " + str(linkCount))
    elif counter[selfNum] != linkCount:
      print("INODE " + selfNum + " HAS " + str(counter[selfNum]) + " LINKS BUT LINKCOUNT IS " + str(linkCount))
    else:
      continue
  
  for n in indirects:
    single = 1
    double = 2
    triple = 3
    current = int(n[5])
    selfNum = int(n[1])
    offsetNum = str(n[3])
    indirectionLevel = int(n[2])
    

    #check if blocks are invalid or reserved
    if current not in blockDict:
      if inodeTable > current:
        if indirectionLevel == triple:
          print("RESERVED TRIPLE BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
        elif indirectionLevel == double:
          print("RESERVED DOUBLE BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
        elif indirectionLevel == single:
          print("RESERVED INDIRECT BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
        else:
          print("RESERVED BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
      elif current > blockNum or current < 0:
        if indirectionLevel == triple:
          print("INVALID TRIPLE BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
        elif indirectionLevel == double:
          print("INVALID DOUBLE BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
        elif indirectionLevel == single:
          print("INVALID INDIRECT BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
        else:
          print("INVALID BLOCK " + str(current) + " IN INODE " + selfNum + " AT OFFSET " + offsetNum)
      else:
        #legal block gets referenced by multiple files (or even multiple times in a single file)
        if indirectionLevel == triple:
          blockDict[current] = (selfNum, "TRIPLE BLOCK ", int(offsetNum))
        elif indirectionLevel == double:
          blockDict[current] = (selfNum, "DOUBLE BLOCK ", int(offsetNum))
        elif indirectionLevel == single:
          blockDict[current] = (selfNum, "INDIRECT BLOCK ", int(offsetNum))
        else:
          blockDict[current] = (selfNum, "BLOCK", int(offsetNum)) 
    #block that is allocated to a file may also appear on the free list
    elif blockDict[current] == 0:
      print("ALLOCATED BLOCK " + str(current) + " ON FREELIST") 
    elif blockDict[current] != 0:
      print("DUPLICATE " + blockDict[current][1] + str(current) + " IN INODE " + blockDict[current][0] + " AT OFFSET " + str(blockDict[current][2]))
      if indirectionLevel == triple:
        blockDict[current] = (selfNum, "TRIPLE BLOCK ", int(offsetNum), 1)
      elif indirectionLevel == double:
        blockDict[current] = (selfNum, "DOUBLE BLOCK ", int(offsetNum), 1)
      elif indirectionLevel == single:
        blockDict[current] = (selfNum, "INDIRECT BLOCK ", int(offsetNum), 1)
      else:
        blockDict[current] = (selfNum, "BLOCK", int(offsetNum), 1)
    

  #check inside of blockDict for any duplicates that may have been missed
  for n in blockDict:
    if blockDict[n] != 0 and len(blockDict[n]) == 4:
      first = blockDict[n][1]
      second = blockDict[n][0]
      third = str(blockDict[n][2])
      print("DUPLICATE " + first + str(n) + " IN INODE " + second + " AT OFFSET " + third)
    else:
      continue

  #block is not referenced by any file and is not on the free list
  for j in range(afterBlock, blockNum):
    if j in blockDict:
      continue
    else:
      number = str(j)
      print("UNREFERENCED BLOCK " + number)


def main():
  if len(sys.argv) != 2:
    sys.stderr.write("Please enter the correct amount of arguments.\n")
    exit(1)
  try:
    file = open(sys.argv[1])
    f = csv.reader(file, delimiter = ',')
    parse(f)
  except IOError:
    sys.stderr.write("The file could not be opened.\n")
    exit(1)
  file.close()

if __name__ == "__main__":
  main()