#!/bin/bash
# NAME: Ethan Wong
# EMAIL: ethanwong@g.ucla.edu
# ID: 305319001

#Test 1 - a pretty typical command
echo OFF | ./lab4b --period=5 --scale=F
if [[ $? -eq 0 ]]
then
	echo "Passed Test 1"
else
	echo "Failed Test 1"
fi


#Test 2 - trying log option
rm -f ./abc.txt
echo OFF | ./lab4b --period=1 --log=abc.txt
if [[ $? -eq 0 ]]
then
	echo "Passed Test 2 pt. 1"
else
	echo "Failed Test 2 pt. 1"
fi
if [ ! -f ./abc.txt ]
then
	echo "Failed Test 2 pt.2"
else 
	echo "Failed Test 2 pt.2"
fi


#Test 3 - unrecognized argument ("monke")
echo OFF | ./lab4b monke --period=3 --scale=C
if [[ $? -eq 0 ]]
then
	echo "Passed Test 1"
else
	echo "Failed Test 1"
fi

rm -rf abc.txt
